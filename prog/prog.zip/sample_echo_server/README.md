# echo server

* 编译：

  ```bash
  cmake .
  make
  ```

* 执行

  ```bash
  ./server
  ```
