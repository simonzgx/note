# echo client

* 编译：

  ```bash
  cmake .
  make
  ```

* 执行

  ```bash
  ./client
  ```

* 退出

  键入`exit`